# Zura Word Counter Launcher – Chrome Extension

Quick launcher for the Zura Web Tools Word Counter.

🔗 https://zurawebtools.com/text-and-writing-tools/word-counter
