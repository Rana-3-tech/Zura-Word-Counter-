const TARGET="https://zurawebtools.com/text-and-writing-tools/word-counter";
chrome.runtime.onInstalled.addListener(()=>{
  chrome.contextMenus.create({id:"open-zura-wordcounter",title:"Open Zura Word Counter",contexts:["all"]});
});
chrome.contextMenus.onClicked.addListener(info=>{
  if(info.menuItemId==="open-zura-wordcounter") chrome.tabs.create({url:TARGET});
});
