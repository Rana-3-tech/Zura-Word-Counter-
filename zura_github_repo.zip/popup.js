const TARGET = "https://zurawebtools.com/text-and-writing-tools/word-counter";

document.getElementById('open').addEventListener('click', () => {
	chrome.tabs.create({ url: TARGET });
});

document.getElementById('copy').addEventListener('click', async () => {
	try {
		await navigator.clipboard.writeText(TARGET);
		const btn = document.getElementById('copy');
		const prev = btn.textContent;
		btn.textContent = 'Copied!';
		setTimeout(() => btn.textContent = prev, 1200);
	} catch (err) {
		console.error('Copy failed', err);
		alert('Unable to copy link.');
	}
});

// Ensure link opens in a new tab if user clicks anchor
document.getElementById('link').addEventListener('click', (e) => {
	e.preventDefault();
	chrome.tabs.create({ url: TARGET });
});
